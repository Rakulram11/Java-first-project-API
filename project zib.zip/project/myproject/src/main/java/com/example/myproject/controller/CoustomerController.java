package com.example.myproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.myproject.Entity.Coustomer;
import com.example.myproject.service.coustomerService;

@RestController
public class CoustomerController {
	@Autowired
	private coustomerService Coustomerservice;
	@PostMapping("/addcoustomer")
	public Coustomer postDetails(@RequestBody Coustomer coustomer) {
		return Coustomerservice.saveDetails(coustomer);
	}
	
	@GetMapping("/getcoustomerById/{Id}")
	public Coustomer fetchDetailsById(@PathVariable Integer Id) {
		return Coustomerservice.getCoustomerDetailsById(Id);
	}
	
	@DeleteMapping("/deletecoustomer/{Id}")
	public String DeleteDetails(@PathVariable Integer Id) {
		return Coustomerservice.deleteDetails(Id);
		
	}
	@PutMapping("/updatecoustomer")
	public Coustomer updateDetails(@RequestBody Coustomer coustomer) {
		return Coustomerservice.updateDetails(coustomer);
	}
}
