package com.example.myproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.myproject.Entity.Coustomer;
public interface CoustomerRepo extends JpaRepository <Coustomer,Integer>{
	 

}
