package com.example.myproject.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.myproject.Entity.Employee;
import com.example.myproject.repository.EmpRepo;
@Service
public class EmService {
	@Autowired
	  private EmpRepo empRepo;
		
		public Employee saveDetails(Employee employee) {
			return empRepo.save(employee);
		}
		
		 public Employee getCoustomerDetailsById(Integer Id ) {
			 return empRepo.findById(Id).orElse(null);
		 }
		 public String deleteDetails(Integer Id) {
			 empRepo.deleteById(Id);
				return "Deleted\s"+Id;
			}
		 public Employee updateDetails(Employee employee) {
			 Employee updateEmp= empRepo.findById(employee.getId()).orElse(null);
			 if(updateEmp!=null) {
				 updateEmp.setFirst_name(employee.getFirst_name());
				 updateEmp.setLast_name(employee.getLast_name());
				 updateEmp.setDate_of_birth(employee.getDate_of_birth());
				 updateEmp.setGender(employee.getGender());
				 updateEmp.setDepartment(employee.getDepartment());
				 updateEmp.setJob_title(employee.getJob_title());
				 updateEmp.setSalary(employee.getSalary());
				 updateEmp.setJoin_date(employee.getJoin_date());
				 updateEmp.setEmail(employee.getEmail());
				 updateEmp.setPhone_number(employee.getPhone_number());
				 updateEmp.setAddress(employee.getAddress());
				 updateEmp.setManager_id(employee.getManager_id());
				 updateEmp.setEmp_status(employee.getEmp_status());
				 updateEmp.setEmp_type(employee.getEmp_type());
				 updateEmp.setAadhar_number(employee.getAadhar_number());
				 updateEmp.setPan_number(employee.getPan_number());
				 updateEmp.setBank_account_number(employee.getBank_account_number());
				 updateEmp.setIfsc_code(employee.getIfsc_code());
				 updateEmp.setEsic_number(employee.getEsic_number());
				 updateEmp.setPf_account_number(employee.getPf_account_number());
				 empRepo.save(updateEmp);
				 return updateEmp;
			 }
			 return null;
		 }
}
