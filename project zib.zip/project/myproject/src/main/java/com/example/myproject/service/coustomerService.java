package com.example.myproject.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.myproject.Entity.Coustomer;
import com.example.myproject.repository.CoustomerRepo;

@Service
public class coustomerService {
	@Autowired
  private CoustomerRepo coustomerRepo;
	
	public Coustomer saveDetails(Coustomer coustomer) {
		return coustomerRepo.save(coustomer);
	}
	
	 public Coustomer getCoustomerDetailsById(Integer Id ) {
		 return coustomerRepo.findById(Id).orElse(null);
	 }
	 public String deleteDetails(Integer Id) {
			coustomerRepo.deleteById(Id);
			return "Deleted\s"+Id;
		}
	 public Coustomer updateDetails(Coustomer coustomer) {
		 Coustomer updateStudent= coustomerRepo.findById(coustomer.getId()).orElse(null);
		 if(updateStudent!=null) {
			 updateStudent.setFirst_name(coustomer.getFirst_name());
			 updateStudent.setLast_name(coustomer.getLast_name());
			 updateStudent.setEmail(coustomer.getEmail());
			 updateStudent.setPhone_number(coustomer.getPhone_number());
			 updateStudent.setAddress(coustomer.getAddress());
			 updateStudent.setCity(coustomer.getCity());
			 updateStudent.setState(coustomer.getState());
			 updateStudent.setPostal_code(coustomer.getPostal_code());
			 updateStudent.setCountry(coustomer.getCountry());
			 coustomerRepo.save(updateStudent);
			 return updateStudent;
		 }
		 return null;
	 }
	 
}
